Основано на https://github.com/RocyLuo/IEC104TCP

Необходимо установить модуль scapy.

для запуска нужно (команды выполнять в отдельных терминалах):
python3 EchoIEC104Server.py
python3 example.py

На данный момент система не работает из-за ошибки в библиотеке scapy.
